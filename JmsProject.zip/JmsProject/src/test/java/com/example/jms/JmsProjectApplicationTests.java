package com.example.jms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JmsProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
